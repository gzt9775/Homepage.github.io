import cdd
#import simul1 as sim
import simul2 as sim
import BinYu as yb 
from multiprocessing import Pool
import time
import numpy as np
import random
import clust_dis as cd
time_s=time.time()
n=200
sigma=[0.6,0.7,0.8]
M=20
paralist=[]
lamda=[0]*5

for i in range(len(sigma)):
    paralist.append([n,sigma[i],2])
for j in range(len(lamda)): # 2.3 tuning procedure lambda_{1n}格点
    lamda[j]=10**(-9+1*j)

def write(): # 把二维数组写进txt文件里
    f=open("simul1.txt","w+")
    f.write("%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s\r\n" % ("n","sigma","lamda","dis","p_err","std","miss0_out","std","miss0_in","std","miss0","std","miss1_out","std","miss1_in","std","miss1","std"))
    for i in range(len(sigma)):
        for j in range(18):
            f.write("%f " % A1[i,j])
        f.write("\r\n")
    f.close()

if __name__ == '__main__':
    pool=Pool(1) # 方便多进程（尽管只用了1个进程）
    A0=[]
    for m in range(M):
        data0=pool.map(sim.sim_1,paralist) # 不同sigma各用一次
        S0=np.zeros((len(sigma),18))
        for i in range(len(sigma)):
            print('i = ', i)
            ConfigurationList0=[]
            ConfigurationList1=[]
            seed=random.sample(range(20),2)
            for j in range(len(lamda)):
                ConfigurationList0.append([data0[i],[0.2,lamda[j],seed[0]]])
                ConfigurationList1.append([data0[i],[0.2,lamda[j],seed[1]]])
            S1=np.array(pool.map(cdd.cdd_1, ConfigurationList0))
            print('===============s1_end===================')
            S2=np.array(pool.map(cdd.cdd_1, ConfigurationList1))
            print('===============s2_end===================')
            para_ind=[]
            for j in range(len(lamda)):
                para_ind.append([S1[j,12],S1[j,13],S2[j,12],S2[j,13]])
            S3=np.array(pool.map(cd.cd_1,para_ind))
            S1[:,3]=(S3[:,0]+S3[:,1])/2
            k=list(S1[:,3]).index(min(S1[:,3]))
            lam=S1[k,2]
            S0[i][0:12]=cdd.cdd_1([data0[i],[0,lam,1]])[0:12]
            # S0[i][12:18]=yb.yb_1([data0[i]])
        A0.append(S0)
        print("m = %d" % m)
    A1=sum(A0)/len(A0)
    for i in range(len(sigma)):
        a=[];b=[];c=[];d=[];e=[];f=[];g=[]
        for j in range(M):
            a.append(A0[j][i,4])
            b.append(A0[j][i,6])
            c.append(A0[j][i,8])
            d.append(A0[j][i,10]) 
            e.append(A0[j][i,12])    
            f.append(A0[j][i,14])
            g.append(A0[j][i,16])   
        A1[i,5]=np.std(a)
        A1[i,7]=np.std(b)
        A1[i,9]=np.std(c)
        A1[i,11]=np.std(d)
        A1[i,13]=np.std(e)
        A1[i,15]=np.std(f)
        A1[i,17]=np.std(g)
    write()
    pool.close()
    pool.join() # 关闭进程

time_e=time.time()
print(time_e-time_s)


















