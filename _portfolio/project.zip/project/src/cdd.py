import numpy as np
import math
from functools import reduce
import time
from sklearn.cluster import KMeans
import cross_v as cv
import clust_dis as cd
################################################ parameter

def cdd_1(ConfigurationList):
    time_start=time.time()
    p=ConfigurationList[0][0]              # probability matrix  
    A=ConfigurationList[0][1]              # data matrix
    indu=ConfigurationList[0][2]           # out-community label
    indv=ConfigurationList[0][3]           # in-community label
    n=ConfigurationList[0][4]              # network size
    sigma=ConfigurationList[0][5]          # sigma
    
    frac=ConfigurationList[1][0]           # fraction of missing value
    lamda=ConfigurationList[1][1]          # tuning parameter
    seed=ConfigurationList[1][2]           # seed
    layers = A.shape[0]
    n = A.shape[1]

    CV=cv.cv_1([A,frac,seed])
    B1=CV[0];B2=CV[1]
    k=8
    epsi=0.005
    s1=len(set(indu));s2=len(set(indv))               # number of community
    tu0=[0]*n;tv0=[0]*n                          
    
    ################################################# initial values
    
    u0=ConfigurationList[0][6]             
    v0=ConfigurationList[0][7]
    p0=1/(1+np.exp(-(np.dot(u0,v0.T))))             
    
    ################################################ initial kmeans
    
    res=KMeans(n_clusters=s1).fit(u0)
    cenu=res.cluster_centers_
    indu0=res.labels_
    for i in range(n):
        tu0[i]=cenu[indu0[i]]            

    res=KMeans(n_clusters=s2).fit(v0)
    cenv=res.cluster_centers_
    indv0=res.labels_
    for j in range(n):
        tv0[j]=cenv[indv0[j]]

    l0 = 0
    for l in range(A.shape[0]):
        #x = A_hat[l].reshape((n ** 2))
        l0 = l0 + np.sum(A[l] * np.dot(u0, v0.T) - np.log(1 + np.exp(np.dot(u0, v0.T))))
    l0 = -l0 / (n ** 2 * layers) + np.sum(u0 ** 2 + v0 ** 2) / (10 ** 10) + lamda * (
                (np.sum((u0 - tu0) ** 2)) + (np.sum((v0 - tv0) ** 2)))
    print(l0)
    #################################################
                                           
    u1=np.zeros((n,k))
    v1=np.zeros((n,k))
    p1=np.zeros((n,n))
    tu1=[0]*n;tv1=[0]*n

    h=1;ss=5*n
    while True:
        for i in range(n):
            z = 0
            for L in range(layers):
                z = z + (np.dot(v0.T,(-A[L][i]+p0[i])*B2[L][i])/(n**2)+2*u0[i]/(10**10)+2*lamda*(u0[i]-tu0[i]))*min(ss,ss/(lamda*n))
            u1[i]=u0[i]-z                 ### update u0           
        res=KMeans(n_clusters=s1,random_state=0).fit(u1)
        cenu=res.cluster_centers_
        indu0=res.labels_
        for i in range(n):
            tu1[i]=cenu[indu0[i]]                   ###### update comu0 by kmeans
            
        for j in range(n):
            z = 0
            for L in range(layers):
                z=(np.dot(u1.T,(-A[L][:,j]+p0[:,j])*B2[L][:,j])/(n**2)+2*v0[j]/(10**10)+2*lamda*(v0[j]-tv0[j]))*min(ss,ss/(lamda*n))
            v1[j]=v0[j]-z                 ### update v0     
        res=KMeans(n_clusters=s2,random_state=0).fit(v1)
        cenv=res.cluster_centers_
        indv0=res.labels_
        for j in range(n):
            tv1[j]=cenv[indv0[j]]                    ### update comv0 by kmeans
        
        p1=1/(1+np.exp(-(np.dot(u1,v1.T))))

        l1 = 0
        for l in range(A.shape[0]):
            # x = A_hat[l].reshape((n ** 2))
            l1 = l1 + np.sum(A[l] * np.dot(u1, v1.T) - np.log(1 + np.exp(np.dot(u1, v1.T))))
        l1 = -l1 / (n ** 2 * layers) + np.sum(u1 ** 2 + v1 ** 2) / (10 ** 10) + lamda * (
                (np.sum((u1 - tu1) ** 2)) + (np.sum((v1 - tv1) ** 2)))

      #  l1=np.sum((-A*np.dot(u1,v1.T)+np.log(1+np.exp(np.dot(u1,v1.T))))*B2)/(n**2)+np.sum(u1**2+v1**2)/(10**10)+lamda*((np.sum((u1-tu1)**2))+(np.sum((v1-tv1)**2)))
        x=np.sum(np.exp(np.dot(u1,v1.T)))
        error=abs(l0-l1)/l0
        print((l1,error,h,lamda,ss)) 
        if error<epsi:
            break
        if l1>l0 or x==float("inf"):
            ss=ss/2; h+=1
        else:
            u0=u1.copy(); v0=v1.copy(); p0=p1.copy(); tu0=tu1; tv0=tv1; l0=l1; h+=1
    
    
    dis=0
    Off_dia=np.ones((n,n))-np.identity(n)
    err=np.sum(((p1-p))**2)/np.sum(p**2)
    print('p1:',np.sum(p1)/n**2,'p:', np.sum(p)/n**2)
    
    M=cd.cd_1([indu,indv,indu0,indv0])
    miss=(M[0]+M[1])/2
    time_end=time.time()
    print('time:',time_end-time_start,'\n')
    return (n, sigma, lamda, dis, err, 0, M[0], 0, M[1], 0, miss, 0, indu0, indv0)



















