###################################### distance between clusters
def cd_1(para):
    indu0 = para[0]; indv0 = para[1]
    indu1 = para[2]; indv1 = para[3]
    n = len(indu0)
    missu = 0; missv = 0
    for i in range(n):
        for j in range(i,n):
            if (indu0[i] == indu0[j] and indu1[i] != indu1[j]) or (indu1[i] == indu1[j] and indu0[i] != indu0[j]) :
                missu += 1
            if (indv0[i] == indv0[j] and indv1[i] != indv1[j]) or (indv1[i]==indv1[j] and indv0[i] != indv0[j]) :
                missv += 1                
    missu=missu/(n*(n-1)/2); missv=missv/(n*(n-1)/2)
    return (missu,missv)
