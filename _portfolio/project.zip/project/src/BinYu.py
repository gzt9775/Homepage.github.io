import numpy as np
from sklearn.cluster import KMeans
import clust_dis as cd
from functools import reduce
import time
############################################### kmeans in Yu Bin's paper.
    
def yb_1(ConfigurationList):    
    ####################### regularized Laplacian
    
    time_s=time.time()
    p=ConfigurationList[0][0]
    A=ConfigurationList[0][1]
    indu=ConfigurationList[0][2]
    indv=ConfigurationList[0][3]
    n=ConfigurationList[0][4]

    s1=len(set(indu));s2=len(set(indv))
    s=min(s1,s2)
    tau=np.sum(A)/n
    S=np.zeros((n,n))
    T=np.zeros((n,n))
    for i in range(n):
        S[i,i]=(sum(A[i])+tau)
        T[i,i]=(sum(A[:,i])+tau)
    L=reduce(np.dot, [np.linalg.inv(S**0.5), A, np.linalg.inv(T**0.5)])
    
    
    ###################### SVD
    
    XL=np.linalg.svd(L)[0][:,range(s)]
    XR=np.linalg.svd(L)[2][range(s),:].T
    
    
    ###################### projection on sphere
    
    for i in range(n):
        XL[i]=XL[i]/(np.dot(XL[i], XL[i].T)+10**(-16))**0.5
        XR[i]=XR[i]/(np.dot(XR[i], XR[i].T)+10**(-16))**0.5
    
    
    ###################### kmeans
    
    res=KMeans(n_clusters=s1).fit(XL)
    indu0=res.labels_

    res=KMeans(n_clusters=s2).fit(XR)
    indv0=res.labels_
   
    K=5;L=5
    Z=np.zeros((n,K));Y=np.zeros((n,L))
    for i in range(n):
        Z[i,indu0[i]]=1
        Y[i,indv0[i]]=1
    B=np.zeros((K,L))
    for i in range(K):
        for j in range(L):
            B[i,j]=reduce(np.dot, [Z[:,i].T, A, Y[:,j]])
            B[i,j]=B[i,j]/(np.sum(Z[:,i])*np.sum(Y[:,j]))
    p1=reduce(np.dot, [Z, B, Y.T])

    time_e=time.time()
    print(time_e-time_s)
    ############################################# misclustering

    M=cd.cd_1([indu,indv,indu0,indv0])
    miss=(M[0]+M[1])/2
    p_err=np.sum((p-p1)**2)/np.sum(p**2)

    return (M[0], 0, M[1], 0, miss, 0)



