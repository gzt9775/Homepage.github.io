import numpy as np
import random
def sim_1(paralist):
    n=paralist[0]
    sigma=paralist[1]
    seed0=paralist[2]
    k=8;layer=20
    u=np.zeros((n,k));u0=np.zeros((n,k))
    v=np.zeros((n,k));v0=np.zeros((n,k))  # n*k矩阵
    p=np.zeros((n,n))
    A=np.zeros((layer,n,n)) # layer*n*n矩阵
    indu=[0]*n;indv=[0]*n # 长度为n的零index列表

    K=6;L=6
    np.random.seed(seed0) 

    # 接下来都打乱index了
    meanu=np.random.normal(0,sigma,(K,k)) # five different alpha_i^*
    y=np.random.permutation(range(n)) # q_j in paper
    for t in range(K): # y[0]~y[200]的indu是0(即in的小组)
        for i in range(int(t*n/K),int((t+1)*n/K)):
            indu[y[i]]=t
            u[y[i]]=meanu[t]
    
    meanv=np.random.normal(0,sigma,(L,k))
    z=np.random.permutation(range(n))
    for t in range(L):
        for j in range(int(t*n/L),int((t+1)*n/L)):
            indv[z[j]]=t
            v[z[j]]=meanv[t]

    p=1/(1+np.exp(-(np.dot(u,v.T)))) # 转为概率

    c=random.sample(range(100000),1)
    np.random.seed(c)

    for l in range(layer):
        A[l] = np.random.binomial(1, p)

    # print(np.sum(p)/n**2,np.sum(A)/n**2)

    for i in range(n): # 初始化
        u0[i]=np.random.normal(0,1,k)
        v0[i]=np.random.normal(0,1,k)
    return(p, A, indu, indv, n, sigma, u0, v0)
