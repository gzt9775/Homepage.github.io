import numpy as np
import random
def cv_1(para):
    A = para[0]
    frac = para[1]
    seed = para[2]
    layers = A.shape[0]
    n = A.shape[1]

    B1 = np.zeros((layers,n, int(frac*n)))
    B2 = np.ones((layers,n,n))#-np.identity(n)
    random.seed(seed)
    for L in range(layers):
        for i in range(n):
            B1[L][i] = random.sample(range(n), int(frac*n))
            for j in range(int(frac*n)):
                B2[L][i][int(B1[L][i][j])] = 0
    return (B1, B2)
